// ─── Theme Toggle ────────────────────────────────────────────────────────────
const themeToggle = document.getElementById('themeToggle');
const toggleLabel = document.getElementById('toggleLabel');
const toggleIcon  = themeToggle.querySelector('.toggle-icon');

themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
  const isLight = document.body.classList.contains('light-mode');
  toggleLabel.textContent = isLight ? 'LIGHT' : 'DARK';
  toggleIcon.textContent  = isLight ? '☀️'   : '🌙';
  localStorage.setItem('theme', isLight ? 'light' : 'dark');
});

if (localStorage.getItem('theme') === 'light') {
  document.body.classList.add('light-mode');
  toggleLabel.textContent = 'LIGHT';
  toggleIcon.textContent  = '☀️';
}

// ─── Custom Cursor ────────────────────────────────────────────────────────────
const cursor = document.getElementById('cursor');
const ring   = document.getElementById('cursorRing');
let mx = 0, my = 0, rx = 0, ry = 0;

document.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;
  cursor.style.left = mx + 'px';
  cursor.style.top  = my + 'px';
});

(function animateRing() {
  rx += (mx - rx) * 0.12;
  ry += (my - ry) * 0.12;
  ring.style.left = rx + 'px';
  ring.style.top  = ry + 'px';
  requestAnimationFrame(animateRing);
})();

document.querySelectorAll('a, button').forEach(el => {
  el.addEventListener('mouseenter', () => {
    cursor.style.transform = 'translate(-50%, -50%) scale(1.8)';
    ring.style.width = '50px'; ring.style.height = '50px';
  });
  el.addEventListener('mouseleave', () => {
    cursor.style.transform = 'translate(-50%, -50%) scale(1)';
    ring.style.width = '36px'; ring.style.height = '36px';
  });
});

// ─── Matrix Rain ──────────────────────────────────────────────────────────────
const canvas = document.getElementById('matrix-canvas');
const ctx    = canvas.getContext('2d');

function resizeCanvas() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

const CHARS = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホ01BCDEF0123456789XZQWERTY';
const FS = 13;
let drops = [];

function initDrops() { drops = Array(Math.floor(canvas.width / FS)).fill(1); }
initDrops();
window.addEventListener('resize', initDrops);

setInterval(() => {
  const light = document.body.classList.contains('light-mode');
  ctx.fillStyle = light ? 'rgba(238,242,247,0.06)' : 'rgba(2,4,8,0.04)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = light ? '#0057a8' : '#00ffe0';
  ctx.font = FS + 'px Share Tech Mono';
  drops.forEach((y, i) => {
    ctx.fillText(CHARS[Math.floor(Math.random() * CHARS.length)], i * FS, y * FS);
    if (y * FS > canvas.height && Math.random() > 0.975) drops[i] = 0;
    else drops[i]++;
  });
}, 60);

// ─── Scroll Reveal ────────────────────────────────────────────────────────────
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const siblings = Array.from(entry.target.parentElement.querySelectorAll('.reveal:not(.visible)'));
    const idx = siblings.indexOf(entry.target);
    setTimeout(() => entry.target.classList.add('visible'), Math.max(0, idx * 80));
    observer.unobserve(entry.target);
  });
}, { threshold: 0.05, rootMargin: '0px 0px -20px 0px' });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

setTimeout(() => {
  document.querySelectorAll('.reveal').forEach(el => {
    if (el.getBoundingClientRect().top < window.innerHeight + 50) {
      el.classList.add('visible');
      observer.unobserve(el);
    }
  });
}, 150);
