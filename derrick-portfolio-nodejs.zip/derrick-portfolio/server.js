const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files (CSS, JS, images) from /public
app.use(express.static(path.join(__dirname, 'public')));

// Serve the main portfolio page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// 404 handler
app.use((req, res) => {
  res.status(404).send('<h1 style="font-family:monospace;color:#00ffe0;background:#020408;padding:2rem;">404 — Page Not Found</h1>');
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🛡  Derrick Akankwasa Portfolio`);
  console.log(`🚀  Server running at http://localhost:${PORT}`);
  console.log(`📁  Serving from: ${__dirname}\n`);
});
