# Akankwasa Derrick — Portfolio Website

A cybersecurity portfolio website for Akankwasa Derrick, Senior Security Engineer based in Kampala, Uganda.

## 🚀 Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) v16 or higher

### Installation

```bash
# 1. Clone or download the project
git clone https://github.com/YOUR_USERNAME/derrick-portfolio.git
cd derrick-portfolio

# 2. Install dependencies
npm install

# 3. Start the server
npm start
```

Then open your browser at **http://localhost:3000**

### Development (with auto-reload)
```bash
npm run dev
```

## 📁 Project Structure

```
derrick-portfolio/
├── server.js            # Express server
├── package.json         # Node.js dependencies & scripts
├── views/
│   └── index.html       # Main HTML page
└── public/
    ├── css/
    │   └── style.css    # All styles (dark + light mode)
    └── js/
        └── main.js      # Client-side JS (cursor, matrix rain, scroll reveal)
```

## 🌐 Deploying to GitHub Pages / Render / Railway

### Option 1 — Render (recommended, free)
1. Push to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your repo, set build command `npm install`, start command `npm start`
4. Deploy — your site will be live with a public URL

### Option 2 — Railway
1. Push to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub

### Option 3 — GitHub Pages (static only)
Copy `views/index.html` to the repo root, rename it `index.html`, and inline the CSS/JS.

## ✏️ Customising

All personal content is in `views/index.html`.  
All styles are in `public/css/style.css`.  
Client interactivity is in `public/js/main.js`.

## 📧 Contact
- **Email:** derrickakankwasa7@gmail.com
- **Phone:** +256 782 040 842
- **Location:** Kampala, Uganda
